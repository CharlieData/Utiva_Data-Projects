CREATE TABLE Sales_Data (
    Sales_Date DATE,
    Sales_YEAR INT,
    Customer_ID INT,
	Customer_Age INT,
    Customer_Gender VARCHAR,
    Country VARCHAR,
    States VARCHAR,
    Product_Category VARCHAR,
    Sub_category VARCHAR,
    Product VARCHAR,
    Order_Quantity INT,
    Unit_Cost INT,
    Unit_Price INT,
    Costs INT,
    Revenue INT
    );

SELECT *
FROM Sales_Data


--TIME-PROFIT ANALYSIS

--Total profit made by BuyBuy from 1Q11 to 4Q16
SELECT SUM(revenue - costs) AS "Total_Profit"
FROM Sales_Data;

--Total profit made by BuyBuy in Q2 of every year from 2011 to 2016
SELECT CASE
           WHEN sd.sales_date BETWEEN '2011-04-01' And '2011-06-30' THEN '2Q11'
				WHEN sd.sales_date BETWEEN '2012-04-01' And '2012-06-30' THEN '2Q12'
				WHEN sd.sales_date BETWEEN '2013-04-01' And '2013-06-30' THEN '2Q13'
				WHEN sd.sales_date BETWEEN '2014-04-01' And '2014-06-30' THEN '2Q14'
				WHEN sd.sales_date BETWEEN '2015-04-01' And '2015-06-30' THEN '2Q15'
				WHEN sd.sales_date BETWEEN '2016-04-01' And '2016-06-30' THEN '2Q16'
	   ELSE 'Others'
	   END AS Quarter,
	   SUM(sd.revenue - sd.costs) AS Profit	
FROM Sales_Data sd
GROUP BY Quarter
ORDER BY Quarter;

--Annual profit made by BuyBuy from the year 2011 to 2016
SELECT sales_year, SUM(revenue - costs) AS Annl_Profit
FROM sales_data
GROUP BY sales_year
ORDER BY sales_year;

-- A chart to visualize the Total Profit made in Q2 from 2011-2016.
See the attached PowerPivot charts


--REGION-PROFIT ANALYSIS

--Write 2 queries that return the countries where BuyBuy has made the most profit and also the least profit of all-time. 
SELECT country, SUM(revenue - costs) AS Profit
FROM sales_data
GROUP BY country
ORDER BY Profit DESC;

--Top-10 most profitable countries for BuyBuy sales operations from 2011 to 2016
SELECT country, SUM(revenue - costs) AS Profit
FROM sales_data
GROUP BY country
ORDER BY Profit DESC
LIMIT 10;

--Top-10 least profitable countries for BuyBuy sales operations
SELECT country, SUM(revenue - costs) AS Profit
FROM sales_data
GROUP BY country
ORDER BY Profit ASC
LIMIT 10;

-- A chart to visualize the Top 10 most profitable countries from 2011-2016.
See the attached PowerPivot charts


-PRODUCT-REVENUE ANALYSIS

--Rank all product categories sold by Buybuy, from least amount to the most amount of all-time revenue generated
SELECT Product_Category, SUM(revenue) AS Revenue
FROM sales_data
GROUP BY Product_Category
ORDER BY Revenue ASC;

--Top-2 product categories offered by Buybuy with an all-time high number of units sold
SELECT Product_Category, SUM(Order_Quantity) AS Unit_sold
FROM sales_data
GROUP BY Product_Category
ORDER BY Unit_sold DESC
LIMIT 2;

--Top 10 highest-grossing products sold by BuyBuy based on all-time profits
SELECT Product, SUM(revenue - costs) AS Profit
FROM sales_data
GROUP BY Product
ORDER BY Profit DESC
LIMIT 10;

-- A chart to visualize the Top 2 Highest selling Product Categories from 2011-2016.
See the attached PowerPivot charts